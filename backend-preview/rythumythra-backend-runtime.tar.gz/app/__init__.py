from __future__ import annotations

import logging
import os
import secrets
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, jsonify, request
from flask_cors import CORS
from sqlalchemy import inspect, text

from config import BASE_DIR, INSTANCE_DIR, Config
from .extensions import db, limiter, migrate
from .routes import (
    accessibility_bp, activities_bp, auth_bp, dashboard_bp, external_bp, farms_bp,
    finances_bp, market_bp, tasks_bp,
)


def _local_secret(instance_dir: Path) -> str:
    """Create a stable local-only signing secret instead of using a hard-coded default."""
    secret_file = instance_dir / ".secret_key"
    if secret_file.exists():
        value = secret_file.read_text(encoding="utf-8").strip()
        if value:
            return value
    value = secrets.token_urlsafe(48)
    secret_file.write_text(value, encoding="utf-8")
    try:
        secret_file.chmod(0o600)
    except OSError:
        pass
    return value


def create_app(test_config: dict | None = None) -> Flask:
    load_dotenv(BASE_DIR / ".env", override=False)
    INSTANCE_DIR.mkdir(parents=True, exist_ok=True)

    app = Flask(__name__, instance_path=str(INSTANCE_DIR), instance_relative_config=True)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)

    if not app.config.get("SECRET_KEY"):
        if app.config.get("APP_ENV") == "production" and not app.config.get("TESTING"):
            raise RuntimeError("SECRET_KEY must be configured outside local development.")
        app.config["SECRET_KEY"] = _local_secret(INSTANCE_DIR)
        app.logger.warning("Using a generated local secret stored in instance/.secret_key; do not delete it while sessions are active.")

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s pid=%(process)d %(name)s %(message)s",
    )

    db.init_app(app)
    migrate.init_app(app, db)
    limiter.init_app(app)

    allowed_origins = app.config.get("CORS_ORIGINS", [])
    if allowed_origins:
        CORS(app, resources={r"/api/*": {"origins": allowed_origins}}, supports_credentials=True,
             allow_headers=["Content-Type", "X-CSRF-Token"], methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"])

    for blueprint in (
        auth_bp, farms_bp, tasks_bp, finances_bp, dashboard_bp,
        market_bp, activities_bp, external_bp, accessibility_bp,
    ):
        app.register_blueprint(blueprint, url_prefix="/api")

    @app.get("/")
    def index():
        return jsonify({
            "app": "Rythu Mythra Local Backend",
            "message": "The API backend is running. The approved landing page is not included or modified in this backend package.",
            "health": "/api/health",
            "api_session": "/api/session",
        })

    @app.get("/api/health")
    def health():
        try:
            db.session.execute(text("SELECT 1"))
            has_users_table = inspect(db.engine).has_table("users")
            if not has_users_table:
                return jsonify({
                    "ok": False,
                    "status": "schema_not_initialized",
                    "database": "connected",
                    "next_step": "Run the database migration commands in README.md.",
                }), 503
        except Exception:
            app.logger.exception("Database health check failed")
            return jsonify({"ok": False, "status": "degraded", "database": "unavailable"}), 503
        return jsonify({"ok": True, "status": "running", "database": "connected", "schema": "ready"})

    @app.after_request
    def add_security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Permissions-Policy", "camera=(self), microphone=(self), geolocation=()")
        if request_path_is_api(response):
            response.headers.setdefault("Cache-Control", "no-store")
        return response

    @app.errorhandler(413)
    def request_too_large(_error):
        return jsonify({"ok": False, "error": {"code": "REQUEST_TOO_LARGE", "message": "Request exceeds the configured 6 MB limit."}}), 413

    @app.errorhandler(404)
    def not_found(_error):
        if request.path.startswith("/api/"):
            return jsonify({"ok": False, "error": {"code": "NOT_FOUND", "message": "API route or record not found."}}), 404
        return _error

    @app.errorhandler(405)
    def method_not_allowed(_error):
        if request.path.startswith("/api/"):
            return jsonify({"ok": False, "error": {"code": "METHOD_NOT_ALLOWED", "message": "This HTTP method is not supported for the API route."}}), 405
        return _error

    @app.errorhandler(500)
    def internal_error(_error):
        db.session.rollback()
        app.logger.error(
            "Unhandled application error: %s",
            _error,
            exc_info=(_error.__class__, _error, _error.__traceback__),
        )
        return jsonify({"ok": False, "error": {"code": "INTERNAL_ERROR", "message": "The server could not complete this request. Check the local log for details."}}), 500

    return app


def request_path_is_api(response) -> bool:
    return request.path.startswith("/api/") and response.mimetype == "application/json"
