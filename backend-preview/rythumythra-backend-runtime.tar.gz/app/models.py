from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import CheckConstraint, UniqueConstraint, event
from sqlalchemy.engine import Engine

from .extensions import db


def new_id() -> str:
    return str(uuid.uuid4())


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.String(36), primary_key=True, default=new_id)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(254), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utc_now)
    profile = db.relationship("FarmerProfile", back_populates="user", uselist=False, cascade="all, delete-orphan")
    farms = db.relationship("Farm", back_populates="owner", cascade="all, delete-orphan")
    tasks = db.relationship("CropTask", back_populates="owner", cascade="all, delete-orphan")
    financial_entries = db.relationship("FinancialEntry", back_populates="owner", cascade="all, delete-orphan")


class FarmerProfile(db.Model):
    __tablename__ = "farmer_profiles"
    user_id = db.Column(db.String(36), db.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    preferred_language = db.Column(db.String(2), nullable=False, default="en")
    district = db.Column(db.String(100), nullable=False, default="")
    village = db.Column(db.String(100), nullable=False, default="")
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utc_now, onupdate=utc_now)
    user = db.relationship("User", back_populates="profile")
    __table_args__ = (CheckConstraint("preferred_language IN ('en','te')", name="ck_profile_language"),)


class Farm(db.Model):
    __tablename__ = "farms"
    id = db.Column(db.String(36), primary_key=True, default=new_id)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    crop_name = db.Column(db.String(80), nullable=False)
    area_acres = db.Column(db.Numeric(10, 2), nullable=False)
    sowing_date = db.Column(db.Date, nullable=True)
    district = db.Column(db.String(100), nullable=False, default="")
    village = db.Column(db.String(100), nullable=False, default="")
    soil_type = db.Column(db.String(80), nullable=False, default="")
    irrigation_source = db.Column(db.String(80), nullable=False, default="")
    electricity_window = db.Column(db.String(120), nullable=False, default="")
    status = db.Column(db.String(20), nullable=False, default="Active")
    client_ref = db.Column(db.String(80), nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utc_now)
    owner = db.relationship("User", back_populates="farms")
    zones = db.relationship("FarmZone", back_populates="farm", cascade="all, delete-orphan")
    tasks = db.relationship("CropTask", back_populates="farm")
    financial_entries = db.relationship("FinancialEntry", back_populates="farm")
    activities = db.relationship("CropActivity", back_populates="farm", cascade="all, delete-orphan")
    __table_args__ = (
        CheckConstraint("area_acres > 0", name="ck_farm_positive_area"),
        CheckConstraint("status IN ('Active','Harvested','Terminated')", name="ck_farm_status"),
        UniqueConstraint("user_id", "client_ref", name="uq_farm_user_client_ref"),
    )


class FarmZone(db.Model):
    __tablename__ = "farm_zones"
    id = db.Column(db.String(36), primary_key=True, default=new_id)
    farm_id = db.Column(db.String(36), db.ForeignKey("farms.id", ondelete="CASCADE"), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    area_acres = db.Column(db.Numeric(10, 2), nullable=True)
    local_condition = db.Column(db.String(300), nullable=False, default="")
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utc_now)
    farm = db.relationship("Farm", back_populates="zones")
    __table_args__ = (CheckConstraint("area_acres IS NULL OR area_acres > 0", name="ck_zone_positive_area"),)


class CropTask(db.Model):
    __tablename__ = "crop_tasks"
    id = db.Column(db.String(36), primary_key=True, default=new_id)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    farm_id = db.Column(db.String(36), db.ForeignKey("farms.id", ondelete="SET NULL"), nullable=True, index=True)
    title = db.Column(db.String(160), nullable=False)
    due_date = db.Column(db.Date, nullable=True)
    status = db.Column(db.String(16), nullable=False, default="pending")
    priority = db.Column(db.String(12), nullable=False, default="normal")
    notes = db.Column(db.String(2000), nullable=False, default="")
    client_ref = db.Column(db.String(80), nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utc_now)
    owner = db.relationship("User", back_populates="tasks")
    farm = db.relationship("Farm", back_populates="tasks")
    __table_args__ = (
        CheckConstraint("status IN ('pending','completed','cancelled')", name="ck_task_status"),
        CheckConstraint("priority IN ('low','normal','high')", name="ck_task_priority"),
        UniqueConstraint("user_id", "client_ref", name="uq_task_user_client_ref"),
    )


class FinancialEntry(db.Model):
    """Money amounts are stored as integer paise to avoid binary-float rounding."""
    __tablename__ = "financial_entries"
    id = db.Column(db.String(36), primary_key=True, default=new_id)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    farm_id = db.Column(db.String(36), db.ForeignKey("farms.id", ondelete="SET NULL"), nullable=True, index=True)
    entry_type = db.Column(db.String(10), nullable=False)
    amount_paise = db.Column(db.BigInteger, nullable=False)
    category = db.Column(db.String(80), nullable=False)
    counterparty = db.Column(db.String(120), nullable=False, default="")
    description = db.Column(db.String(500), nullable=False, default="")
    transaction_date = db.Column(db.Date, nullable=False)
    due_date = db.Column(db.Date, nullable=True)
    payment_mode = db.Column(db.String(20), nullable=False, default="cash")
    client_ref = db.Column(db.String(80), nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utc_now)
    owner = db.relationship("User", back_populates="financial_entries")
    farm = db.relationship("Farm", back_populates="financial_entries")
    payments = db.relationship("FinancialPayment", back_populates="entry", cascade="all, delete-orphan", order_by="FinancialPayment.paid_on")
    __table_args__ = (
        CheckConstraint("entry_type IN ('INCOME','EXPENSE')", name="ck_financial_entry_type"),
        CheckConstraint("amount_paise > 0", name="ck_financial_positive_amount"),
        CheckConstraint("payment_mode IN ('cash','bank_transfer','upi','credit','other')", name="ck_financial_payment_mode"),
        UniqueConstraint("user_id", "client_ref", name="uq_financial_user_client_ref"),
    )

    @property
    def paid_paise(self) -> int:
        return sum(payment.amount_paise for payment in self.payments)

    @property
    def outstanding_paise(self) -> int:
        return max(0, self.amount_paise - self.paid_paise)

    @property
    def payment_status(self) -> str:
        if self.paid_paise <= 0:
            return "unpaid"
        if self.paid_paise >= self.amount_paise:
            return "paid"
        return "partial"


class FinancialPayment(db.Model):
    __tablename__ = "financial_payments"
    id = db.Column(db.String(36), primary_key=True, default=new_id)
    entry_id = db.Column(db.String(36), db.ForeignKey("financial_entries.id", ondelete="CASCADE"), nullable=False, index=True)
    amount_paise = db.Column(db.BigInteger, nullable=False)
    paid_on = db.Column(db.Date, nullable=False)
    method = db.Column(db.String(20), nullable=False, default="cash")
    note = db.Column(db.String(250), nullable=False, default="")
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utc_now)
    entry = db.relationship("FinancialEntry", back_populates="payments")
    __table_args__ = (
        CheckConstraint("amount_paise > 0", name="ck_payment_positive_amount"),
        CheckConstraint("method IN ('cash','bank_transfer','upi','other')", name="ck_payment_method"),
    )


class CropActivity(db.Model):
    __tablename__ = "crop_activities"
    id = db.Column(db.String(36), primary_key=True, default=new_id)
    farm_id = db.Column(db.String(36), db.ForeignKey("farms.id", ondelete="CASCADE"), nullable=False, index=True)
    zone_id = db.Column(db.String(36), db.ForeignKey("farm_zones.id", ondelete="SET NULL"), nullable=True)
    activity_type = db.Column(db.String(24), nullable=False)
    activity_date = db.Column(db.Date, nullable=False)
    note = db.Column(db.String(1000), nullable=False, default="")
    data_source = db.Column(db.String(20), nullable=False, default="USER_ENTERED")
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utc_now)
    farm = db.relationship("Farm", back_populates="activities")
    zone = db.relationship("FarmZone")
    __table_args__ = (
        CheckConstraint("activity_type IN ('observation','irrigation','spraying','fertilizer','labour','harvest','other')", name="ck_activity_type"),
        CheckConstraint("data_source IN ('USER_ENTERED','ASSISTED')", name="ck_activity_source"),
    )


# SQLite does not enforce foreign keys unless the connection explicitly enables it.
@event.listens_for(Engine, "connect")
def _set_sqlite_pragmas(dbapi_connection, connection_record):
    module = dbapi_connection.__class__.__module__
    if "sqlite3" not in module:
        return
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.execute("PRAGMA busy_timeout=15000")
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.close()
