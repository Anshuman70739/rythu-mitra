from decimal import Decimal, ROUND_HALF_UP
from marshmallow import Schema, fields, validate, validates_schema, ValidationError

class RegisterSchema(Schema):
    full_name = fields.String(required=True, validate=validate.Length(min=2, max=100))
    email = fields.Email(required=True, validate=validate.Length(max=254))
    password = fields.String(required=True, load_only=True, validate=validate.Length(min=10, max=128))
    preferred_language = fields.String(load_default="en", validate=validate.OneOf(["en", "te"]))


class LoginSchema(Schema):
    email = fields.Email(required=True, validate=validate.Length(max=254))
    password = fields.String(required=True, load_only=True, validate=validate.Length(min=1, max=128))


class ProfileSchema(Schema):
    full_name = fields.String(validate=validate.Length(min=2, max=100))
    preferred_language = fields.String(validate=validate.OneOf(["en", "te"]))
    district = fields.String(validate=validate.Length(max=100))
    village = fields.String(validate=validate.Length(max=100))


class FarmSchema(Schema):
    name = fields.String(required=True, validate=validate.Length(min=2, max=100))
    crop_name = fields.String(required=True, validate=validate.Length(min=2, max=80))
    area_acres = fields.Decimal(required=True, as_string=True, places=2, rounding=ROUND_HALF_UP,
                                validate=validate.Range(min=Decimal("0.01"), max=Decimal("100000")))
    sowing_date = fields.Date(allow_none=True, load_default=None)
    district = fields.String(load_default="", validate=validate.Length(max=100))
    village = fields.String(load_default="", validate=validate.Length(max=100))
    soil_type = fields.String(load_default="", validate=validate.Length(max=80))
    irrigation_source = fields.String(load_default="", validate=validate.Length(max=80))
    electricity_window = fields.String(load_default="", validate=validate.Length(max=120))
    status = fields.String(load_default="Active", validate=validate.OneOf(["Active", "Harvested", "Terminated"]))
    client_ref = fields.String(allow_none=True, load_default=None, validate=validate.Length(max=80))


class FarmUpdateSchema(Schema):
    name = fields.String(validate=validate.Length(min=2, max=100))
    crop_name = fields.String(validate=validate.Length(min=2, max=80))
    area_acres = fields.Decimal(as_string=True, places=2, rounding=ROUND_HALF_UP,
                                validate=validate.Range(min=Decimal("0.01"), max=Decimal("100000")))
    sowing_date = fields.Date(allow_none=True)
    district = fields.String(validate=validate.Length(max=100))
    village = fields.String(validate=validate.Length(max=100))
    soil_type = fields.String(validate=validate.Length(max=80))
    irrigation_source = fields.String(validate=validate.Length(max=80))
    electricity_window = fields.String(validate=validate.Length(max=120))
    status = fields.String(validate=validate.OneOf(["Active", "Harvested", "Terminated"]))

    @validates_schema
    def at_least_one_field(self, data, **kwargs):
        if not data:
            raise ValidationError("Provide at least one valid field to update.")


class ZoneSchema(Schema):
    name = fields.String(required=True, validate=validate.Length(min=2, max=100))
    area_acres = fields.Decimal(allow_none=True, load_default=None, as_string=True, places=2,
                                rounding=ROUND_HALF_UP,
                                validate=validate.Range(min=Decimal("0.01"), max=Decimal("100000")))
    local_condition = fields.String(load_default="", validate=validate.Length(max=300))


class TaskSchema(Schema):
    farm_id = fields.String(allow_none=True, load_default=None, validate=validate.Length(equal=36))
    title = fields.String(required=True, validate=validate.Length(min=2, max=160))
    due_date = fields.Date(allow_none=True, load_default=None)
    priority = fields.String(load_default="normal", validate=validate.OneOf(["low", "normal", "high"]))
    notes = fields.String(load_default="", validate=validate.Length(max=2000))
    client_ref = fields.String(allow_none=True, load_default=None, validate=validate.Length(max=80))


class TaskUpdateSchema(Schema):
    status = fields.String(required=True, validate=validate.OneOf(["pending", "completed", "cancelled"]))


class FinancialEntrySchema(Schema):
    farm_id = fields.String(allow_none=True, load_default=None, validate=validate.Length(equal=36))
    entry_type = fields.String(required=True, validate=validate.OneOf(["INCOME", "EXPENSE"]))
    amount_inr = fields.Decimal(required=True, as_string=True, places=2, rounding=ROUND_HALF_UP,
                                validate=validate.Range(min=Decimal("0.01")))
    paid_amount_inr = fields.Decimal(load_default=Decimal("0.00"), as_string=True, places=2,
                                     rounding=ROUND_HALF_UP,
                                     validate=validate.Range(min=Decimal("0")))
    category = fields.String(required=True, validate=validate.Length(min=2, max=80))
    counterparty = fields.String(load_default="", validate=validate.Length(max=120))
    description = fields.String(load_default="", validate=validate.Length(max=500))
    transaction_date = fields.Date(load_default=None, allow_none=True)
    due_date = fields.Date(load_default=None, allow_none=True)
    payment_mode = fields.String(load_default="cash", validate=validate.OneOf(["cash", "bank_transfer", "upi", "credit", "other"]))
    client_ref = fields.String(allow_none=True, load_default=None, validate=validate.Length(max=80))

    @validates_schema
    def paid_not_above_amount(self, data, **kwargs):
        amount = data.get("amount_inr")
        paid = data.get("paid_amount_inr", Decimal("0"))
        if amount is not None and paid > amount:
            raise ValidationError({"paid_amount_inr": ["Paid amount cannot exceed the total amount."]})


class PaymentSchema(Schema):
    amount_inr = fields.Decimal(required=True, as_string=True, places=2, rounding=ROUND_HALF_UP,
                                validate=validate.Range(min=Decimal("0.01")))
    paid_on = fields.Date(load_default=None, allow_none=True)
    method = fields.String(load_default="cash", validate=validate.OneOf(["cash", "bank_transfer", "upi", "other"]))
    note = fields.String(load_default="", validate=validate.Length(max=250))


class ActivitySchema(Schema):
    farm_id = fields.String(required=True, validate=validate.Length(equal=36))
    zone_id = fields.String(allow_none=True, load_default=None, validate=validate.Length(equal=36))
    activity_type = fields.String(required=True, validate=validate.OneOf([
        "observation", "irrigation", "spraying", "fertilizer", "labour", "harvest", "other"
    ]))
    activity_date = fields.Date(required=True)
    note = fields.String(load_default="", validate=validate.Length(max=1000))
    data_source = fields.String(load_default="USER_ENTERED", validate=validate.OneOf(["USER_ENTERED"]))


class MarketEstimateSchema(Schema):
    quantity_kg = fields.Decimal(required=True, as_string=True, places=2, rounding=ROUND_HALF_UP,
                                 validate=validate.Range(min=Decimal("0.01")))
    price_per_quintal = fields.Decimal(required=True, as_string=True, places=2, rounding=ROUND_HALF_UP,
                                       validate=validate.Range(min=Decimal("0")))
    transport_cost_inr = fields.Decimal(load_default=Decimal("0"), as_string=True, places=2,
                                        rounding=ROUND_HALF_UP, validate=validate.Range(min=Decimal("0")))
    loading_unloading_cost_inr = fields.Decimal(load_default=Decimal("0"), as_string=True, places=2,
                                                rounding=ROUND_HALF_UP, validate=validate.Range(min=Decimal("0")))
    commission_inr = fields.Decimal(load_default=Decimal("0"), as_string=True, places=2,
                                    rounding=ROUND_HALF_UP, validate=validate.Range(min=Decimal("0")))
    other_costs_inr = fields.Decimal(load_default=Decimal("0"), as_string=True, places=2,
                                     rounding=ROUND_HALF_UP, validate=validate.Range(min=Decimal("0")))
    weight_deduction_kg = fields.Decimal(load_default=Decimal("0"), as_string=True, places=2,
                                         rounding=ROUND_HALF_UP, validate=validate.Range(min=Decimal("0")))
    bag_count = fields.Integer(allow_none=True, load_default=None, validate=validate.Range(min=1, max=100000))
    weight_deduction_kg_per_bag = fields.Decimal(load_default=Decimal("0"), as_string=True, places=2,
                                                   rounding=ROUND_HALF_UP,
                                                   validate=validate.Range(min=Decimal("0")))
    moisture_deduction_percent = fields.Decimal(load_default=Decimal("0"), as_string=True, places=2,
                                                rounding=ROUND_HALF_UP,
                                                validate=validate.Range(min=Decimal("0"), max=Decimal("100")))
    payment_timing = fields.String(load_default="unknown", validate=validate.OneOf([
        "immediate", "1_7_days", "8_15_days", "over_15_days", "unknown"
    ]))
    offer_name = fields.String(load_default="User-entered offer", validate=validate.Length(max=100))


    @validates_schema
    def bag_deduction_needs_count(self, data, **kwargs):
        per_bag = data.get("weight_deduction_kg_per_bag", Decimal("0"))
        bag_count = data.get("bag_count")
        if per_bag > 0 and bag_count is None:
            raise ValidationError({"bag_count": ["Enter the number of bags when using a per-bag deduction."]})


class MarketCompareSchema(Schema):
    offers = fields.List(fields.Nested(MarketEstimateSchema), required=True,
                         validate=validate.Length(min=2, max=5))
