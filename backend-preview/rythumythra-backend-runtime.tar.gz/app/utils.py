from __future__ import annotations

from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from flask import jsonify, request
from marshmallow import ValidationError

from .security import api_error

PAISE = Decimal("100")
CENT = Decimal("0.01")


def json_payload() -> dict:
    value = request.get_json(silent=True)
    return value if isinstance(value, dict) else {}


def load_schema(schema, payload: dict):
    try:
        return schema.load(payload), None
    except ValidationError as exc:
        return None, (jsonify({"ok": False, "error": {"code": "VALIDATION_ERROR", "fields": exc.messages}}), 400)


def to_paise(value: Decimal | str | int) -> int:
    amount = Decimal(str(value)).quantize(CENT, rounding=ROUND_HALF_UP)
    return int(amount * PAISE)


def from_paise(value: int | None) -> str:
    amount = (Decimal(int(value or 0)) / PAISE).quantize(CENT)
    return format(amount, ".2f")


def iso_date(value: date | None) -> str | None:
    return value.isoformat() if value else None


def model_not_configured(feature: str):
    return jsonify({
        "ok": False,
        "status": "NOT_CONFIGURED",
        "data_source": "UNAVAILABLE",
        "error": {
            "code": "FEATURE_NOT_CONFIGURED",
            "message": f"{feature} is not connected yet. No sample result or prediction was generated.",
        },
    }), 501


def commit_or_rollback():
    from .extensions import db
    try:
        db.session.commit()
        return None
    except Exception:
        db.session.rollback()
        raise
